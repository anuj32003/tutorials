# Deploy example voting app

## Deploy and test example voting appliaction

1. **Get the application's source code**: \
   Use git to clone application's repo:
   ```console
   $ git clone https://github.com/dockersamples/example-voting-app.git
   Cloning into 'example-voting-app'
   ...
   Resolving deltas: 100% (439/439), done.
   ```
   change to the application's directory: 
   ```console
   cd example-voting-app
   ```
   Open README.md file in preview. 
   >NOTE: On your workstation you have an options to deploy application with docker compose and/or kuberentes, on cloud environments we can deploy with kubernetes only.

2. **Inspect the application's source code**:
   
   Take a look at microservices source code and Dockerfiles that used to build `vote`, `result`, `worker` microservices. Note that multistage build is used for `vote`.
   
   Study `docker-compose.yml`, note which build target is used for `vote` service.

   >NOTE: Usually we need to have all images  prebuilt (for all the services that are using build process - refer compose file) before deploy on kubernetes. Thankfully, the Docker community has built and published these images.

   Check the deployments and services manifests in `k8s-sepcifications` folder.

   It is almost as easy to deploy full solution with all it's microservices as to run `kubectl create -f k8s-specifications/`, however given our cluster setup details, we need to perform small modifications in user-faced services mainfests `vote` and `result`.

3. **Deploy the solution**: \
    Remove `spec.ports.nodePort` field from `vote` and `result` services specifications:
    
    ```diff
     - name: "vote-service"
       port: 5000
       targetPort: 80
    -   nodePort: 31000
     selector:
       app: result
    ```

    ```diff
     - name: "result-service"
       port: 5001
       targetPort: 80
    -   nodePort: 31001
     selector:
       app: result
    ```
    Thus kubernetes control plane will allocate an **available** port from a range 30000-32767 and we will be able to avoid conflicts.

    Deploy the application:
    ```console
    $ kubectl apply -f k8s-specifications/
    deployment.apps/db created
    service/db created
    deployment.apps/redis created
    service/redis created
    deployment.apps/result created
    service/result created
    deployment.apps/vote created
    service/vote created
    deployment.apps/worker created
    ```
 4. **Expose the solution to cluster network**: \
    Check the services:
    ```console
    $ kubectl get svc
    NAME        TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)          AGE
    db          ClusterIP   10.100.166.89    <none>        5432/TCP         6m4s
    redis       ClusterIP   10.100.227.155   <none>        6379/TCP         6m4s
    result      NodePort    10.100.66.77     <none>        5001:31990/TCP   6m4s
    vote        NodePort    10.100.54.43     <none>        5000:32141/TCP   **6m4s**
    ```
    note random node ports numbers that have been allocated to user-facing services in PORT(S) section.

     5. **Forward the services**:

    We could access the service using `curl` from worker node network, however access via a browser is usually required during the development stages. To achieve this, we will forward the NodePort service's traffic to our cloud environment with kubectl port forward command:
    ```console
    # in different terminal tabs:
    $ kubectl port-forward service/vote 8080:8080
    $ kubectl port-forward service/result 8081:8081
    # Example ouput for curl localhost:8080
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <title>Cats vs Dogs!</title>
        <base href="/index.html">
    ...
      <body>
    ...
        <h3>Cats vs Dogs!</h3>
        <form id="choice" name='form' method="POST" action="/">
          <button id="a" type="submit" name="vote" class="a" value="a">Cats</button>
          <button id="b" type="submit" name="vote" class="b" value="b">Dogs</button>
        </form>
    ...
      </body>
    ```

    this will forward traffic from cluster network to coder cloud IDE's localhost:specified port.

    Our cloud IDE in turn will auto-forward this port to coder's server public url. You will be prompted:

    <div style="display: flex;justify-content: center; padding: 20px;">
      <img src="media/img/port-fwd-prompt.png" alt="drawing" style="width:400px;align:justify;"/>
    </div>

    You can also find list of all forwarded port on "Ports" tab:

    <div style="display: flex;justify-content: center; padding: 20px;">
      <img src="media/img/port-fwd-tab.png" alt="drawing" style="width:800px;align:justify;"/>
    </div>

    This tab can be handy if you missed the prompt or (sometimes this can happen) it didn't appear. \
    Repeat the steps for second user-faced service (change localhost's port to different number so it won't overlap).
    Now you can test and work with both `vote` and `result` services in browser.

    Vote service:

    <div style="display: flex;justify-content: center; padding: 20px;">
      <img src="media/img/vote-srv.png" alt="drawing" style="width:800px;align:justify;"/>
    </div>
    Result service:

    <div style="display: flex;justify-content: center; padding: 20px;">
      <img src="media/img/result-srv.png" alt="drawing" style="width:800px;align:justify;"/>
    </div>